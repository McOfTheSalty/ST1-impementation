import numpy as np

import cv2
import matplotlib.pyplot as plt
from tensorflow.keras.models import load_model

import tkinter as tk

model = load_model('saved_model.h5')




gui = tk.Tk()
gui.title = 'Pizza Segmenter'
gui.geometry = '550 x 350'

instructions = tk.Label(text = "Place image in same folder as main.py, enter file name in box below e.g. test.jpg")
instructions.grid(row=0, column=0, columnspan=3)

entry = tk.Entry()
entry.grid(row=1, column=0, columnspan=3)

def segment():
    imgName = entry.get()
    try:
        img = cv2.imread(imgName)
        print(img.max())
        img = cv2.resize(img, (256,256), interpolation = cv2.INTER_AREA)[:,:,::-1]/255.0
        img = np.array([img])
        img = model.predict(img)
        img = img[0]
        cv2.imwrite("out.png", img[:,:,::-1]*255)
        

        plt.figure()
        plt.imshow(img)
        plt.show()
        
    except:
        entry.delete(0, tk.END)
        entry.insert(tk.END, "Incorrect file name")


segment = tk.Button(text='Segment', command = segment)
segment.grid(row=2, column=0, columnspan=3)




gui.mainloop()